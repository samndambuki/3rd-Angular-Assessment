export interface Tweet {
  id: number;
  userId: number;
  title: string;
  body: string;
}